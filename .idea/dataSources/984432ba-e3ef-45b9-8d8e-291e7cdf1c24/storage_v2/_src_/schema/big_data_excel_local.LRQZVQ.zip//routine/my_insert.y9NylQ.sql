create
    definer = root@localhost procedure my_insert()
BEGIN
	DECLARE
i INT DEFAULT 1;
	WHILE
i <= 100 DO#插入语句
			INSERT INTO `o_order_item` ( `id`, `create_by`, `update_by`, `create_time`, `update_time`, `is_deleted`, `pay_time`, `delivery_time`, `confirm_time`, `code`, `receiver`, `mobile`, `description` )
		VALUES
			(
				NULL,
				'123@163.com',
				'456@163.com',
				now(),
				now(),
				FALSE,
				now(),
				now(),
				now(),
				substring( RAND()* 1000000000000, 1, 11 ),
				'石头',
				substring( RAND()* 1000000000000, 1, 11 ),
				'没啥备注'
			);

		SET i = i + 1;

END WHILE;
COMMIT;

END;

